"""Repository layer for data persistence."""

