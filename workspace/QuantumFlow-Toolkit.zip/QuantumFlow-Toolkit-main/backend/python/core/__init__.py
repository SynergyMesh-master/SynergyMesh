"""Core domain entities and value objects."""

