"""Quantum backend integrations for Cirq, Qiskit, and PennyLane."""

