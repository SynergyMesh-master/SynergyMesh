"""Use cases (application-specific business logic)."""

