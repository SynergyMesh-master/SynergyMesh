"""API layer (FastAPI application and endpoints)."""

